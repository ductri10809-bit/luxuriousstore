<?php
/**
 * nguoi_dung.php - Model bang users
 */
require_once __DIR__ . '/../cau_hinh/ket_noi_csdl.php';

class NguoiDung
{
    private PDO $db;

    public function __construct()
    {
        $this->db = ketNoiCSDL();
    }

    public function timTheoEmail(string $email): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row ? $this->dinhDang($row) : null;
    }

    public function timTheoId(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE user_id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? $this->dinhDang($row) : null;
    }

    public function tao(array $data): int
    {
        $stmt = $this->db->prepare(
            'INSERT INTO users (username, fullname, email, password, phone) VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $data['email'],
            $data['ho_ten'],
            $data['email'],
            $data['password'],
            $data['sdt'] ?? null,
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function capNhat(int $id, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE users SET fullname = ?, email = ?, phone = ? WHERE user_id = ?'
        );
        return $stmt->execute([
            $data['ho_ten'],
            $data['email'],
            $data['sdt'] ?? null,
            $id,
        ]);
    }

    private function dinhDang(array $row): array
    {
        return [
            'id'      => (int) $row['user_id'],
            'ho_ten'  => $row['fullname'] ?? '',
            'email'   => $row['email'] ?? '',
            'sdt'     => $row['phone'] ?? '',
            'password'=> $row['password'] ?? '',
        ];
    }
}
