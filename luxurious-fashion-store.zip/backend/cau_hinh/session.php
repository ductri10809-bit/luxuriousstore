<?php
/**
 * session.php - Khoi tao session
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
    ]);
}

function layUserId(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

function datUserId(int $id): void
{
    $_SESSION['user_id'] = $id;
}

function xoaSession(): void
{
    session_destroy();
}
