/**
 * gio_hang.js (trang)
 */
document.addEventListener('DOMContentLoaded', () => {
  const listEl = document.getElementById('cart-list');
  const emptyEl = document.getElementById('cart-empty');
  const subtotalEl = document.getElementById('cart-subtotal');
  const totalEl = document.getElementById('cart-total');
  const form = document.getElementById('form-dat-hang');

  function render() {
    const items = GioHang.lay();
    const total = GioHang.tongTien();

    if (items.length === 0) {
      listEl.innerHTML = '';
      emptyEl.hidden = false;
      if (subtotalEl) subtotalEl.textContent = Chung.formatGia(0);
      if (totalEl) totalEl.textContent = Chung.formatGia(0);
      form?.querySelector('#btn-dat-hang')?.setAttribute('disabled', 'disabled');
      return;
    }

    emptyEl.hidden = true;
    form?.querySelector('#btn-dat-hang')?.removeAttribute('disabled');

    listEl.innerHTML = items.map(item => `
      <article class="cart-item" data-id="${item.id}" data-variant="${item.variant_id || ''}">
        <img class="cart-item__img" src="${item.hinh_anh || ''}" alt="">
        <div>
          <h3 class="cart-item__name">${item.ten}</h3>
          ${item.mau_sac ? `<p class="cart-item__variant">Màu: ${item.mau_sac}</p>` : ''}
          <p class="cart-item__price">${Chung.formatGia(item.gia)}</p>
          <div class="cart-item__qty">
            <button type="button" class="btn-qty-minus" aria-label="Giảm">−</button>
            <span>${item.so_luong}</span>
            <button type="button" class="btn-qty-plus" aria-label="Tăng">+</button>
          </div>
        </div>
        <button type="button" class="cart-item__remove btn-xoa">Xóa</button>
      </article>
    `).join('');

    if (subtotalEl) subtotalEl.textContent = Chung.formatGia(total);
    if (totalEl) totalEl.textContent = Chung.formatGia(total);
  }

  render();
  document.addEventListener('cartUpdated', render);

  listEl?.addEventListener('click', (e) => {
    const row = e.target.closest('.cart-item');
    if (!row) return;
    const id = parseInt(row.dataset.id, 10);
    const variantId = row.dataset.variant ? parseInt(row.dataset.variant, 10) : null;

    if (e.target.classList.contains('btn-xoa')) {
      GioHang.xoa(id, variantId);
      render();
      return;
    }
    const item = GioHang.lay().find(i => GioHang.cartKey(i) === `${id}_${variantId || 0}`);
    if (!item) return;
    if (e.target.classList.contains('btn-qty-plus')) {
      GioHang.capNhatSoLuong(id, variantId, item.so_luong + 1);
      render();
    }
    if (e.target.classList.contains('btn-qty-minus') && item.so_luong > 1) {
      GioHang.capNhatSoLuong(id, variantId, item.so_luong - 1);
      render();
    }
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const items = GioHang.lay();
    if (!items.length) return;

    const payload = {
      ho_ten: form.ho_ten.value.trim(),
      sdt: form.sdt.value.trim(),
      email: form.email.value.trim(),
      dia_chi: form.dia_chi.value.trim() + (form.ghi_chu?.value ? `\nGhi chú: ${form.ghi_chu.value}` : ''),
      items: items.map(i => ({
        product_id: i.id,
        id: i.id,
        gia: i.gia,
        so_luong: i.so_luong,
      })),
    };

    try {
      const btn = document.getElementById('btn-dat-hang');
      btn.disabled = true;
      btn.textContent = 'Đang xử lý...';
      const result = await Chung.goiApi('dat_hang.php', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      if (result.success) {
        GioHang.luu([]);
        render();
        const modal = document.getElementById('order-success');
        const msg = document.getElementById('order-success-msg');
        if (msg) {
          msg.textContent = `Đơn hàng #${result.data?.order_id || ''} đã được ghi nhận. Chúng tôi sẽ liên hệ sớm.`;
        }
        modal.hidden = false;
        form.reset();
      } else {
        Chung.toast(result.message || 'Đặt hàng thất bại');
      }
      btn.disabled = false;
      btn.textContent = 'Đặt hàng';
    } catch (err) {
      Chung.toast('Không thể đặt hàng. Vui lòng thử lại.');
      console.error(err);
    }
  });
});
