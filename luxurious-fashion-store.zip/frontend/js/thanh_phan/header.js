/**
 * header.js
 */
document.addEventListener('componentLoaded', (e) => {
  if (e.detail.selector !== '#header') return;

  const cartBadge = document.getElementById('cart-count');
  const wishBadge = document.getElementById('wishlist-count');

  function capNhatBadge() {
    if (cartBadge) cartBadge.textContent = GioHang.dem();
    if (wishBadge) wishBadge.textContent = YeuThich.dem();
  }

  capNhatBadge();
  document.addEventListener('cartUpdated', capNhatBadge);
  document.addEventListener('wishlistUpdated', capNhatBadge);
});
