/**
 * chung.js
 */
const API_BASE = '/luxurious-fashion-store/backend/api';

const Chung = {
  formatGia(gia) {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      maximumFractionDigits: 0,
    }).format(gia || 0);
  },

  layQueryParam(key) {
    return new URLSearchParams(window.location.search).get(key);
  },

  async goiApi(endpoint, options = {}) {
    const response = await fetch(`${API_BASE}/${endpoint}`, {
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      ...options,
    });
    return response.json();
  },

  toast(message) {
    let el = document.querySelector('.toast');
    if (!el) {
      el = document.createElement('div');
      el.className = 'toast';
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.classList.remove('show'), 2200);
  },

  ganGiaChoThe(grid, products) {
    if (!grid || !products) return;
    grid.querySelectorAll('.product-card').forEach(card => {
      const id = parseInt(card.dataset.id, 10);
      const sp = products.find(p => p.id === id);
      if (sp) card.dataset.gia = sp.gia;
    });
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (typeof taiComponent === 'function') {
    taiComponent('#header', '../../thanh_phan/header/header.html');
    taiComponent('#footer', '../../thanh_phan/footer/footer.html');
  }
});
