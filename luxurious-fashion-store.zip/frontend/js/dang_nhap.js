/**
 * dang_nhap.js
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('form-dang-nhap');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
      const result = await Chung.goiApi('dang_nhap.php', {
        method: 'POST',
        body: JSON.stringify(data)
      });

      if (result.success) {
        window.location.href = '../trang_chu/trang_chu.html';
      } else {
        alert(result.message || 'Dang nhap that bai');
      }
    } catch (error) {
      alert('Loi ket noi server');
    }
  });
});
